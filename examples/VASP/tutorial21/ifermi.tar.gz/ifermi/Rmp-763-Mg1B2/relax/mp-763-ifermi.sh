#!/bin/bash

#SBATCH --partition=dense --ntasks=1 --cpus-per-task=48 --time=1-0

# record start date and host


ifermi plot --property velocity -a 90 --interpolation-factor 10 --output fermi-surface.jpg --property-colormap bwr --hide-labels
cp fermi-surface.html ../../IFERMI/mp-763-Mg1B2-fs.html
cp fermi_info.dat ../../IFERMI/mp-763-Mg1B2-fs.dat
cp fermi-surface.jpg ../../IFERMI/mp-763-Mg1B2-fs.jpg
